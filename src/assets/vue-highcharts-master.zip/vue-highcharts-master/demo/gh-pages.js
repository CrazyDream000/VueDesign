var ghpages = require('gh-pages');

ghpages.publish('assets', function(err) {});