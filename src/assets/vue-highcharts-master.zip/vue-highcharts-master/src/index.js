/**
 * Created by superman on 2017/2/19.
 */

import VueHighcharts from './VueHighcharts.vue'

export default VueHighcharts;